# Demo

![ezgif com-video-to-gif (1)](https://user-images.githubusercontent.com/7893859/62185427-1de14880-b380-11e9-88c6-ee408c66323f.gif)

## Steps to run project
1. Create a config.dart file in lib folder
2. Add the following code

`String getApiKey() {
  return 'YOUR_TMDB_API_KEY';
}
`
